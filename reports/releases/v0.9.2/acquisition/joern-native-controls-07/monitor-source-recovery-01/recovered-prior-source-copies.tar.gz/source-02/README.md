# monitor07 Darwin ABI-v3 integration candidate

This private candidate extends `v092-native-monitor07-integration-01` in a
separate directory. It is a source-only integration proposal; it does not
change the canonical DataFlowBench worktree.

## Provider binding and file integrity

Darwin query selection uses `PinnedDarwinNativeProvider` ABI v3. The caller
must supply the absolute adapter source path and SHA-256 plus the absolute
native dylib path and SHA-256. The query executes the exact pinned Python
source bytes, checks the adapter ABI and provider identity, and requires the
provider to report the same dylib digest. Module source reads and dylib load
boundaries reject symlinks in every path component and compare file identity
before and after use. The provider also verifies the dylib content digest.
No environment variable selects either artifact. Linux continues to use its
existing procfs provider.

## ABI-v3 row provenance and completeness

The receiver accepts only these exact ABI-v3 command sources:

- `proc_pidpath`: full command path, successful path status, and a first-table
  row matched by PID, PPID, and birth tuple in the second KERN_PROC_ALL table;
- `sysctl_kern_proc_all.p_comm`: short command fallback with its recorded
  nonnegative path errno and the same first-table revalidation witness;
- `sysctl_kern_proc_all.second_table_new.p_comm`: atomic identity and short
  command fields observed only in the second table, with no path attempt,
  errno inference, or revalidation claim.

The older `proc_pidinfo.pbi_comm` source remains in the finite compatibility
allowlist for pre-pinned rows. Wildcard source-family matching is rejected.
ABI-v3 rows must carry exact typed source flags, origin and witness metadata,
full PID/PPID/birth/state fields, and a command string that agrees with its
executable. Provider evidence must match the v3 identity and explicit pins,
report exactly one first and one revalidation syscall, and satisfy the row,
PID-zero, and second-table count equations.
The provider's `enumerated_pid_count` includes raw first-table records
(including excluded PID zero) plus second-table-only additions, while
`returned_pid_count` excludes that first-table PID-zero entry. Therefore 773
returned rows with one excluded first PID-zero record correctly report 774
enumerated records.

Second-table-only rows are retained. The outer monitor accepts a nonowned
kernel-command fallback only when the exact PID, PPID, and birth tuple brackets
the complete `ps` table and its executable basename matches the command. A
missing `ps` row, changed identity, or basename mismatch stays an unconditional
fresh contender. Owned rows are skipped only when their own birth tuple matches
the tracked identity.

## Validation boundary

The copied Python fixture suite passed 48 tests with Python 3.13:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/Users/dave/.codex/worktrees/9f01/dataflowbench/reports/releases/v0.9.2/acquisition/joern-native-controls-06 /opt/homebrew/bin/python3.13 -B -m unittest -q test_reconciliation_policy.py
```

Fixtures cover exact-source rejection, module and dylib symlink ancestors,
ABI-v3 count and provenance failures including the 773/774/PID-zero count,
retained second-table-only rows, positive
outer identity bridging, missing or mismatched `ps` rows, PID reuse, and exact
owned birth identity. No C compilation, dylib load, Darwin API probe, canonical
monitor query, or analyzer qualification was performed by this candidate.
