# monitor07 Darwin provider integration candidate

This is a private source-only candidate copied from `joern-native-controls-06`.
It is not canonical and does not alter the DataFlowBench worktree.

## Darwin provider binding

Darwin query selection now uses `PinnedDarwinNativeProvider` and has no
implicit legacy-libproc fallback. The caller must pass all four explicit
bindings to `snapshot_query.query` or `process_reconciliation.run_query_child`:

- absolute Python adapter path and source SHA-256;
- absolute native dylib path and dylib SHA-256.

The adapter source is read through a bounded, non-symlink file check; the
exact pinned bytes are compiled and executed, avoiding a second path-based
source read. The provider must report the same library digest it loaded. The
snapshot coverage records both absolute paths and both content digests. The
child receives these values as explicit command-line arguments; no environment
variable lookup selects a provider. Missing or partial pins fail closed.

Linux still selects the existing procfs provider without Darwin pins.

## Kernel command fallback

Kernel `p_comm` fallback rows are never classified by the frozen native-name
rule when their exact identity cannot be bridged. A nonowned fallback row is
accepted only when the same PID, PPID, and birth identity appears in both
native tables and the complete `ps` row's executable basename matches the
kernel command name. Otherwise one typed fresh contender is emitted for that
PID, even if the frozen name classifier would ignore it. The explicit boolean
fallback flag is type-checked against a recognized kernel source family;
`sysctl_kern_proc_all.*.p_comm` variants are routed through the same guard.
An owned row is skipped only when that row's own birth identity matches the
tracked birth.

This candidate accepts the provider02 ABI-v2 row form. ABI-v3
second-table-only rows need their distinct typed provenance and are not
claimed as integrated here.

## Validation

The copied Python fixture suite was run with Python 3.13:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/Users/dave/.codex/worktrees/9f01/dataflowbench/reports/releases/v0.9.2/acquisition/joern-native-controls-06 /opt/homebrew/bin/python3.13 -B -m unittest -q test_reconciliation_policy.py
```

Result: 44 tests passed. No C compilation, dylib loading, Darwin API call,
canonical edit, or monitor invocation was performed.
