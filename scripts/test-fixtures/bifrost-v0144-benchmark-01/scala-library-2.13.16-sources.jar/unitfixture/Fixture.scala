package unitfixture
object Fixture { val value = "unit-only" }
