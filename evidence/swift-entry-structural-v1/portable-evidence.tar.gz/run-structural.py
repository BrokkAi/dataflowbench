import sys,json,hashlib,shutil,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/private/tmp/dfb-220-full108-20260928');src=repo/'adapters/codeql/swift-entry-structural-v1'
sys.path.insert(0,str(repo/'scripts'));import swift_v2_process as process
from swift_artifact_closure import snapshot,compare
p=json.loads((src/'preregistration.json').read_text());out=r/'structural-attempt-01';out.mkdir(exist_ok=False)
for rel,digest in p['files'].items():assert hashlib.sha256((src/rel).read_bytes()).hexdigest()==digest
shutil.copy2(src/'preregistration.json',out/'preregistration.json')
results=[]
for control in p['controls']:
 d=Path(control['directory']);d.mkdir(); record={'id':control['id'],'scored':False}
 try:
  assert shutil.disk_usage(r).free>40*1024**3
  x=process.run(control['extract'],d,'extract',150,cwd=repo);print(control['id'],'extract',x['exit_status'],flush=True)
  assert x['exit_status']==0 and not x['timed_out'],'ExtractionFailed'
  before=snapshot(d/'database');(d/'pre-query-closure.json').write_text(json.dumps(before,indent=2)+'\n')
  start=time.monotonic()
  for phase in control['phases']:
   assert shutil.disk_usage(r).free>40*1024**3
   remaining=75-(time.monotonic()-start);assert remaining>0,'BudgetExhausted'
   x=process.run(phase['argv'],d,phase['name'],remaining,cwd=repo)
   print(control['id'],phase['name'],x['exit_status'],flush=True)
   assert x['exit_status']==0 and not x['timed_out'],'QueryFailed:'+phase['name']
  facts=dict(json.loads((d/'structure.json').read_text())['#select']['tuples']);record['facts']=facts
  failures=[k for k in p['expected_zero'] if facts.get(k)!=0]+[k for k in p['expected_one'] if facts.get(k)!=1]+[k for k in p['expected_positive'] if facts.get(k,0)<1]
  for k in ['declarations','throw-statements','throw-cfg','throw-exits']:
   if facts.get(k)!=control['expected_'+k.replace('-','_')]:failures.append(k)
  record['structural_failures']=failures;record['status']='passed-count-assertions' if not failures else 'failed-structural-assertions'
  (d/'post-query-closure.json').write_text(json.dumps({'delta':compare(before,snapshot(d/'database'))},indent=2)+'\n')
 except Exception as e:record['status']='incomplete';record['reason']=str(e)
 results.append(record);(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(record),flush=True)
 if record['status']=='incomplete':break
