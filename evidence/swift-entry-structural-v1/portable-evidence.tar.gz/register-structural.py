import json,hashlib,shlex
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/private/tmp/dfb-220-full108-20260928');src=repo/'adapters/codeql/swift-entry-structural-v1';out=r/'structural-attempt-01'
cli='/private/tmp/dfb-full108-assets-20260928/codeql-runtime/codeql/codeql';swift='/private/tmp/dfb-full108-assets-20260928/swift-expanded/swift-6.3.3-RELEASE-osx-package.pkg/Payload/usr/bin/swiftc'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan={'schema':1,'claim':'structural diagnostic only; flow results separately observed, no accuracy or scoring gate','budgets':{'extract_seconds':150,'shared_query_decode_seconds':75,'threads':2,'requested_ram_mb':2048,'minimum_free_gib':40},'files':{str(p.relative_to(src)):sha(p) for p in src.rglob('*') if p.is_file() and p.suffix in ['.swift','.ql','.qll','.yml']},'candidate_extractor_manifest_sha256':sha(r/'candidate-extractor-manifest.json'),'candidate_pack_manifest_sha256':sha(r/'candidate-pack-manifest.json'),'cli_sha256':sha(cli),'swift_sha256':sha(swift),'controls':[],'expected_zero':['wrong-entry-file','wrong-entry-module','unowned-declarations','wrong-declaration-owner','duplicate-declaration','duplicate-indices','non-dense-indices','nested-return-leak','throw-to-sink'],'expected_one':['entries','normal-exits'],'expected_positive':['nested-return-scopes','closure-scopes','script-conditions'],'original_ten_control_failure':'preserved','nonqualification':['auxiliary macro declarations','lazy extraction trigger','aggregate resource containment','full108 activation'],'preparation':{str(p.relative_to(r)):sha(p) for n in [1,2,3] for p in (r/f'structural-preparation-{n:02}').glob('*') if p.is_file()}}
for name,count in [('branch',6),('throw',3)]:
 d=out/name
 compiler=[swift,'-swift-version','6','-Onone','-sdk','/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk','-target','arm64-apple-macosx26.5','-module-name','DataFlowBenchTaintSwift','-module-cache-path',str(d/'cache'),str(src/name/'main.swift'),str(src/name/'Library.swift'),'-o',str(d/'never-executed')]
 extract=[cli,'database','create',str(d/'database'),'--language=swift','--search-path='+str(r/'candidate-extractor'),'--source-root='+str(src/name),'--threads=2','--ram=2048','--command='+shlex.join(compiler)]
 phases=[]
 for q in ['structure','identity','diagnostics','kernel-flow']:
  phases += [{'name':q,'argv':[cli,'query','run',str(src/f'queries/{q}.ql'),'--database='+str(d/'database'),'--output='+str(d/f'{q}.bqrs'),'--additional-packs='+str(r/'candidate-packs'),'--threads=2','--ram=2048']},{'name':q+'-decode','argv':[cli,'bqrs','decode',str(d/f'{q}.bqrs'),'--format=json','--output='+str(d/f'{q}.json')]}]
 plan['controls'].append({'id':name,'directory':str(d),'extract':extract,'phases':phases,'expected_declarations':count,'expected_throw_statements':int(name=='throw'),'expected_throw_cfg':int(name=='throw'),'expected_throw_exits':int(name=='throw'),'compiler_order_labels':[8,9,10,15,16,17] if name=='branch' else [9,10,13]})
(src/'preregistration.json').write_text(json.dumps(plan,indent=2)+'\n')
print('preregistration sha256',sha(src/'preregistration.json'))
