import sys,json,hashlib,shutil,shlex,time
from pathlib import Path
r=Path(__file__).resolve().parent
repo=Path('/private/tmp/dfb-220-full108-20260928'); src=repo/'adapters/codeql/swift-entry-structural-v1'
sys.path.insert(0,str(repo/'scripts')); import swift_v2_process as process
out=r/'structural-preparation-03';out.mkdir(exist_ok=False)
cli='/private/tmp/dfb-full108-assets-20260928/codeql-runtime/codeql/codeql'
swift='/private/tmp/dfb-full108-assets-20260928/swift-expanded/swift-6.3.3-RELEASE-osx-package.pkg/Payload/usr/bin/swiftc'
commands=[]
for name in []:
 a=[swift,'-dump-ast','-swift-version','6','-sdk','/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk','-target','arm64-apple-macosx26.5','-module-name','DataFlowBenchTaintSwift','-module-cache-path',str(out/'cache'),str(src/name/'main.swift'),str(src/name/'Library.swift')]
 commands.append((name,a,30))
commands.append(('query-check',[cli,'query','compile',str(src/'queries/structure.ql'),str(src/'queries/identity.ql'),'--check-only','--additional-packs='+str(r/'candidate-packs'),'--threads=2','--ram=2048'],75))
(out/'preregistration.json').write_text(json.dumps({'purpose':'compiler legality/AST and QL syntax preparation only; no extraction or evaluation','files':{str(p.relative_to(src)):hashlib.sha256(p.read_bytes()).hexdigest() for p in src.rglob('*') if p.is_file()},'commands':commands},indent=2)+'\n')
for name,a,budget in commands:
 assert shutil.disk_usage(r).free>40*1024**3
 x=process.run(a,out,name,budget,cwd=repo);print(name,json.dumps(x),flush=True)
 print((out/(name+'.stderr')).read_text()[-3000:],flush=True)
 if x['exit_status'] or x['timed_out']:break
