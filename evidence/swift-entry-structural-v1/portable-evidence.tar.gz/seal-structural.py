import json,sys,hashlib,shutil
from pathlib import Path
r=Path(__file__).resolve().parent;out=r/'structural-attempt-01';repo=Path('/private/tmp/dfb-220-full108-20260928')
sys.path.insert(0,str(repo/'scripts'));import swift_v2_process as process
from swift_artifact_closure import snapshot,compare
cli='/private/tmp/dfb-full108-assets-20260928/codeql-runtime/codeql/codeql'
commands=[{'case':n,'argv':[cli,'bqrs','decode',str(out/n/'identity.bqrs'),'--format=json','--entities=all','--output='+str(out/n/'identity-all.json')],'bqrs_sha256':hashlib.sha256((out/n/'identity.bqrs').read_bytes()).hexdigest()} for n in ['branch','throw']]
(out/'supplemental-decode-registration.json').write_text(json.dumps({'reason':'default decoded labels lack entity IDs; decode retained BQRS only, no new query or extraction','deadline_seconds_per_decode':15,'not_part_of_original_75_seconds':True,'commands':commands},indent=2)+'\n')
for c in commands:
 assert shutil.disk_usage(r).free>40*1024**3
 d=out/c['case'];x=process.run(c['argv'],d,'identity-all-decode',15,cwd=repo);print(c['case'],x['exit_status'],flush=True)
 before=snapshot(d/'database');after=snapshot(d/'database');(d/'sealed-closure.json').write_text(json.dumps({'before':before,'after':after,'delta':compare(before,after),'scope':'post-query closure only; original query-time cache changes retained separately'},indent=2)+'\n')
