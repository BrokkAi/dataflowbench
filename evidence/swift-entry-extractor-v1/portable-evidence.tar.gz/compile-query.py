import sys,json,shutil
from pathlib import Path
r=Path(__file__).resolve().parent
sys.path.insert(0,'/private/tmp/dfb-220-full108-20260928/scripts');import swift_v2_process as process
out=r/'query-compile-01';out.mkdir(exist_ok=False)
assert shutil.disk_usage(r).free>40*1024**3
cli='/private/tmp/dfb-full108-assets-20260928/codeql-runtime/codeql/codeql'
a=[cli,'query','compile',str(r/'queries/diagnostics.ql'),'--additional-packs='+str(r/'candidate-packs'),'--threads=2','--ram=2048']
print(json.dumps(process.run(a,out,'compile',75,cwd=r)))
print((out/'compile.stderr').read_text()[-7000:])
