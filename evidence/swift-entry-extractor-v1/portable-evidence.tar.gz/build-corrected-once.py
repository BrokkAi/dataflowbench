import hashlib,json,os,signal,subprocess,time,shutil
from pathlib import Path
root=Path(__file__).resolve().parent
out=root/'build-attempt-02';out.mkdir(exist_ok=False)
cmd=[str(root/'bazel-9.0.0-darwin-arm64'),'--batch',f'--output_user_root={root}/bazel-cache','--host_jvm_args=-Xmx2048m','build','//swift/extractor:extractor.real','--jobs=2','--local_resources=cpu=2','--local_resources=memory=4096',f'--repository_cache={root}/repository-cache',f'--override_repository=swift-prebuilt-macos={root}/compiler-prebuilt']
cmd += ['--repo_env=CC=/Library/Developer/CommandLineTools/usr/bin/clang','--repo_env=CXX=/Library/Developer/CommandLineTools/usr/bin/clang++','--repo_env=DEVELOPER_DIR=/Library/Developer/CommandLineTools','--action_env=DEVELOPER_DIR=/Library/Developer/CommandLineTools','--repo_env=BAZEL_CXXOPTS=-std=c++20:-isysroot:/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk','--repo_env=BAZEL_CONLYOPTS=-isysroot:/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk','--repo_env=BAZEL_LINKOPTS=-isysroot:/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk','--verbose_failures']
plan=json.loads((root/'preregistration.json').read_text())
assert plan['patch_sha256']==hashlib.sha256((root/'repair.patch').read_bytes()).hexdigest()
assert shutil.disk_usage(root).free >=40*1024**3
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
start=time.monotonic(); reason=None; peak=0; observed=set(); minfree=shutil.disk_usage(root).free
with (out/'build.log').open('wb') as log:
 p=subprocess.Popen(cmd,cwd=root/'source',stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env={**os.environ,'TMPDIR':str(root/'tmp'),'XDG_CACHE_HOME':str(root/'xdg-cache')})
 while p.poll() is None:
  free=shutil.disk_usage(root).free;minfree=min(minfree,free)
  rows=subprocess.check_output(['ps','-axo','pid=,ppid=,pgid=,rss='],text=True)
  procs=[list(map(int,l.split())) for l in rows.splitlines()]
  group=[r for r in procs if r[2]==p.pid];observed.update(r[0] for r in group);peak=max(peak,sum(r[3] for r in group))
  if free <40*1024**3:reason='disk-reserve';break
  if time.monotonic()-start>=900:reason='timeout';break
  time.sleep(1)
 if reason:
  try:os.killpg(p.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   p.wait(timeout=5)
 rc=p.wait()
rows=subprocess.check_output(['ps','-axo','pid=,ppid=,pgid=,rss='],text=True)
remaining=[l for l in rows.splitlines() if int(l.split()[2])==p.pid]
record={'exit_code':rc,'stop_reason':reason,'elapsed_seconds':time.monotonic()-start,'minimum_free_bytes':minfree,'observed_group_peak_rss_kib':peak,'tracked_pids':sorted(observed),'remaining_process_group':remaining,'cleanup_scope':'Batch mode process group; escaped descendants are not proven absent. No retries.','status':'build-success' if rc==0 and not reason and not remaining else 'build-failed-or-incomplete'}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
