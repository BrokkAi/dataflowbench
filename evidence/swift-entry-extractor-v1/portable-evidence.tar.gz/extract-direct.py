import sys,json,shlex,shutil,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent
sys.path.insert(0,'/private/tmp/dfb-220-full108-20260928/scripts');import swift_v2_process as process
out=r/'controls-attempt-01/direct-positive';out.mkdir(parents=True,exist_ok=False)
assert shutil.disk_usage(r).free>40*1024**3
assets=Path('/private/tmp/dfb-full108-assets-20260928');cli=assets/'codeql-runtime/codeql/codeql';compiler=assets/'swift-expanded/swift-6.3.3-RELEASE-osx-package.pkg/Payload/usr/bin/swiftc';sdk=Path('/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk')
args=[str(compiler),'-swift-version','6','-Onone','-sdk',str(sdk),'-target','arm64-apple-macosx26.5','-module-name','DataFlowBenchTaintSwift','-module-cache-path',str(out/'cache'),str(r/'controls/direct-positive/main.swift'),'-o',str(out/'never-executed')]
a=[str(cli),'database','create',str(out/'database'),'--language=swift','--search-path='+str(r/'candidate-extractor'),'--source-root='+str(r/'controls/direct-positive'),'--threads=2','--ram=2048','--command='+shlex.join(args)]
(out/'preregistration.json').write_text(json.dumps({'argv':a,'extract_deadline':150,'shared_query_decode_deadline':75,'package_manifest_sha256':hashlib.sha256((r/'candidate-extractor-manifest.json').read_bytes()).hexdigest(),'query_pack_manifest_sha256':hashlib.sha256((r/'candidate-pack-manifest.json').read_bytes()).hexdigest(),'lane':'patched-extractor-diagnostic-only'},indent=2)+'\n')
print(json.dumps(process.run(a,out,'extract',150,cwd=r)));print((out/'extract.stderr').read_text()[-2200:])
