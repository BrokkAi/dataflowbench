import sys,json,shutil,time,hashlib,shlex,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent
sys.path.insert(0,'/private/tmp/dfb-220-full108-20260928/scripts');import swift_v2_process as process
from swift_extraction_integrity import inspect_logs
from swift_artifact_closure import snapshot,compare
cli='/private/tmp/dfb-full108-assets-20260928/codeql-runtime/codeql/codeql'
compiler='/private/tmp/dfb-full108-assets-20260928/swift-expanded/swift-6.3.3-RELEASE-osx-package.pkg/Payload/usr/bin/swiftc';sdk='/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk'
names=['direct-negative','local-overwrite-positive','local-overwrite-negative','array-element-positive','array-element-negative','callback-registration-positive','callback-registration-negative','wrapped','wrapped-negative']
manifest=json.loads((r/'control-manifest.json').read_text())['files']
for f,h in manifest.items():assert hashlib.sha256((r/'controls'/f).read_bytes()).hexdigest()==h
outroot=r/'controls-attempt-01'
(outroot/'remaining-preregistration.json').write_text(json.dumps({'case_order':names,'deadline_extract':150,'deadline_query_and_decode_total':75,'memory_request_mb':2048,'minimum_free_gib':40,'manifest_sha256':hashlib.sha256((r/'control-manifest.json').read_bytes()).hexdigest(),'queries_sha256':hashlib.sha256((r/'query-manifest.json').read_bytes()).hexdigest(),'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'classification':'diagnostic-only'},indent=2)+'\n')
stop=None;results=[]
for name in names:
 if stop:results.append({'id':name,'status':'not-attempted','reason':stop});continue
 out=outroot/name;out.mkdir(exist_ok=False);rec={'id':name,'status':'attempted'}
 try:
  assert shutil.disk_usage(r).free>40*1024**3,'DiskReserveReached'
  args=[compiler,'-swift-version','6','-Onone','-sdk',sdk,'-target','arm64-apple-macosx26.5','-module-name','DataFlowBenchTaintSwift','-module-cache-path',str(out/'cache'),str(r/f'controls/{name}/main.swift'),'-o',str(out/'never-executed')]
  def run(a,label,budget):
   if budget<=0:raise RuntimeError('BudgetExhausted')
   result=process.run(a,out,label,budget,cwd=r)
   assert not result['timed_out'] and result['elapsed_seconds']<=budget,'BudgetExhausted:'+label
   assert result['exit_status']==0,'CommandFailed:'+label
   assert result['cleanup_status']=='tracked-processes-stopped','CleanupUncertain'
  run([cli,'database','create',str(out/'database'),'--language=swift','--search-path='+str(r/'candidate-extractor'),'--source-root='+str(r/f'controls/{name}'),'--threads=2','--ram=2048','--command='+shlex.join(args)],'extract',150)
  rec['extraction_integrity']=inspect_logs(out/'database/log/swift/extractor');assert rec['extraction_integrity']['ready_for_observation'],'ExtractionIncomplete'
  assert (out/'database/db-swift/swift.dbscheme').read_bytes()==(r/'candidate-extractor/swift/swift.dbscheme').read_bytes(),'SchemaMismatch'
  start=time.monotonic()
  for q in ['entry','diagnostics','kernel-flow']:
   run([cli,'query','run',str(r/f'queries/{q}.ql'),'--database='+str(out/'database'),'--output='+str(out/f'{q}.bqrs'),'--additional-packs='+str(r/'candidate-packs'),'--threads=2','--ram=2048'],q,75-(time.monotonic()-start))
   run([cli,'bqrs','decode',str(out/f'{q}.bqrs'),'--format=json','--output='+str(out/f'{q}.json')],q+'-decode',75-(time.monotonic()-start))
  rec['analysis_seconds']=time.monotonic()-start
  rec['entry_rows']=json.loads((out/'entry.json').read_text())['#select']['tuples']
  roles=json.loads((out/'diagnostics.json').read_text())['#select']['tuples'];rec['exact_endpoints']=[x for x in roles if x[5]==1]
  rec['flow_rows']=json.loads((out/'kernel-flow.json').read_text())['#select']['tuples']
  rec['status']='completed'
 except Exception as e:rec['status']='incomplete';rec['reason']=str(e);stop=str(e)
 (out/'observation.json').write_text(json.dumps(rec,indent=2)+'\n');results.append(rec);print(json.dumps(rec),flush=True)
 (outroot/'remaining-results.json').write_text(json.dumps(results,indent=2)+'\n')
(outroot/'remaining-results.json').write_text(json.dumps(results,indent=2)+'\n')
print('done; stop='+str(stop),flush=True)
