import sys,json,shutil,time,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent
sys.path.insert(0,'/private/tmp/dfb-220-full108-20260928/scripts');import swift_v2_process as process
out=r/'controls-attempt-01/direct-positive';cli='/private/tmp/dfb-full108-assets-20260928/codeql-runtime/codeql/codeql'
(out/'query-preregistration.json').write_text(json.dumps({'queries_sha256':hashlib.sha256((r/'query-manifest.json').read_bytes()).hexdigest(),'shared_seconds':75,'order':['entry','diagnostics','kernel-flow'],'outcomes':'not yet observed'},indent=2)+'\n')
start=time.monotonic()
for name in ['entry','diagnostics','kernel-flow']:
 assert shutil.disk_usage(r).free>40*1024**3
 remain=75-(time.monotonic()-start)
 if remain<=0:raise RuntimeError('BudgetExhausted')
 result=process.run([cli,'query','run',str(r/f'queries/{name}.ql'),'--database='+str(out/'database'),'--output='+str(out/f'{name}.bqrs'),'--additional-packs='+str(r/'candidate-packs'),'--threads=2','--ram=2048'],out,name,remain,cwd=r)
 print(name,result['exit_status'],flush=True)
 if result['exit_status'] or result['timed_out']:break
 remain=75-(time.monotonic()-start)
 if remain<=0:raise RuntimeError('BudgetExhausted')
 result=process.run([cli,'bqrs','decode',str(out/f'{name}.bqrs'),'--format=json','--output='+str(out/f'{name}.json')],out,name+'-decode',remain,cwd=r)
 if result['exit_status'] or result['timed_out']:break
 print((out/f'{name}.json').read_text(),flush=True)
