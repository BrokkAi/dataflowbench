import sys,json,os,hashlib,shutil
from pathlib import Path
r=Path(__file__).resolve().parent
sys.path.insert(0,'/private/tmp/dfb-220-full108-20260928/scripts')
import swift_v2_process as process
out=r/'startup-attempt-02';out.mkdir(exist_ok=False)
assert shutil.disk_usage(r).free>40*1024**3
argv=[str(r/'candidate-extractor/swift/tools/osx64/extractor'),'-version']
plan={'argv':argv,'deadline':60,'purpose':'frontend Options.inc declares version Flag FrontendOption; source main forwards to performFrontend','prior':'candidate-version-timeout.json','package_manifest_sha256':hashlib.sha256((r/'candidate-extractor-manifest.json').read_bytes()).hexdigest(),'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'diagnostic_only':True,'no_controls_on_failure':True}
(out/'preregistration.json').write_text(json.dumps(plan,indent=2)+'\n')
env={**os.environ,'DYLD_PRINT_LIBRARIES':'1','CODEQL_EXTRACTOR_SWIFT_TRAP_DIR':str(out/'trap'),'CODEQL_EXTRACTOR_SWIFT_SOURCE_ARCHIVE_DIR':str(out/'src'),'CODEQL_EXTRACTOR_SWIFT_SCRATCH_DIR':str(out/'scratch')}
result=process.run(argv,out,'startup',60,env=env,cwd=r)
print(json.dumps(result));print((out/'startup.stdout').read_text());print((out/'startup.stderr').read_text()[-1800:])
